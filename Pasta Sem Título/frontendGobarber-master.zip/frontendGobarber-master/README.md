# frontendGobarber
Projeto desenvolvido em React para estudo. Site para cadastro de agendamentos de uma barbearia.
